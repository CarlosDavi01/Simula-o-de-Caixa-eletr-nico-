# Simula-o-de-Caixa-eletr-nico-
Construído com o auxílio do criar do de conteúdo "I love já"
